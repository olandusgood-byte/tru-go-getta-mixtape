# TRU GO GETTA WORLD Unreal Vertical Slice Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver a one-district Unreal 5.8 vertical slice that reuses the verified TGG WORLD v15.1 career, battle, mission, and backend contracts.

**Architecture:** Keep deterministic career/battle/mission rules in a portable C++ core with no Unreal dependency. Wrap that core in a thin Unreal module, then layer district/avatar/vehicle/studio UI and authenticated backend adapters around it.

**Tech Stack:** Unreal Engine 5.8, C++17, Blueprints, Supabase, EOS, LiveKit, Git LFS.

**Spec:** `docs/superpowers/specs/2026-09-15-tgg-world-unreal-vertical-slice-design.md`

## Global Constraints
- Do not fabricate production evidence or rewards.
- No privileged Supabase credentials in the client.
- Preserve v15.1 tier thresholds and battle scoring weights.
- Start with one district, one vehicle, one studio, one studio mission, one rap battle.
- Keep domain rules testable without Unreal.

---

### Task 1: Portable gameplay core
**Files:**
- Create: `Source/TGGWorld/Core/TGGCareerCore.h/.cpp`
- Create: `Source/TGGWorld/Core/TGGBattleCore.h/.cpp`
- Create: `Source/TGGWorld/Core/TGGMissionCore.h/.cpp`
- Create: `Tests/TGGCoreTests.cpp`
- Create: `CMakeLists.txt`

**Interfaces:**
- `tgg::CareerTierFromReputation(int64_t)` -> `std::string`
- `tgg::Battle` with `PlayRound(double timing, double style, double crowd, double opponentScore)`
- `tgg::MissionState::SetProgress(double)` and status transitions

- [x] Write failing unit tests for tier boundaries, scoring/clamping, battle completion, and mission transitions.
- [x] Run tests and verify RED because production core does not exist.
- [x] Implement minimal portable core.
- [x] Run tests and verify GREEN.
- [x] Commit.

### Task 2: Unreal project/module scaffold
**Files:**
- Create: `TGGWorld.uproject`
- Create: `Source/TGGWorld/TGGWorld.Build.cs`
- Create: `Source/TGGWorld/TGGWorld.h/.cpp`
- Create: `Source/TGGWorld.Target.cs`
- Create: `Source/TGGWorldEditor.Target.cs`
- Create: `Config/DefaultGame.ini`
- Create: `Config/DefaultEngine.ini`
- Create: `scripts/verify_scaffold.py`

- [x] Write scaffold verifier first.
- [x] Verify RED before `.uproject` and module files exist.
- [x] Add minimal Unreal 5.8 project/module/config files.
- [x] Verify GREEN with scaffold verifier and JSON parse.
- [x] Commit.

### Task 3: Player/career adapter
Create Unreal subsystem interfaces for auth state, career refresh, and tier display. Backend writes remain server-authoritative. Add adapter tests with a fake transport; no network calls in unit tests.

### Task 4: Creator District + avatar + movement + one vehicle
Build the first playable district, player pawn/controller, avatar loadout data, movement, interaction prompts, and one Chaos vehicle. Use starter/proxy assets until gameplay is proven.

### Task 5: Studio mission vertical loop
Implement mission board/HUD for `MVP_FIRST_SESSION`, Starter Studio interaction, Creator OS session launch handoff, saved-session refresh, and authoritative reward display. Never create fake evidence on failure.

### Task 6: Rap battle slice
Connect portable BattleCore to a three-round rap battle UI, deterministic test hooks, presentation randomness for opponent score, results, and career-safe reward request boundary.

### Task 7: Online + voice seam
Add EOS session adapter and LiveKit voice adapter behind interfaces. Verify gameplay remains usable when either service is unavailable.

### Task 8: Packaging and vertical-slice QA
Package Windows Development build, run login/movement/vehicle/studio/mission/battle/persistence/2-user session checks, instrument Sentry/PostHog, then produce a release-readiness report.

## Fast-Lane Execution Status — 2026-09-15

### Task 3: Player/career adapter
- [x] Portable auth/career adapter fails closed without authentication.
- [x] Client-safe Supabase RPC transport uses publishable key + signed-in user JWT only.
- [x] In-game email/password sign-in source added; password is not persisted.
- [x] Live `tgg_world_mvp_v1_bootstrap_player` refresh maps XP/reputation/audience/level into the tested tier rules.
- [x] Native HUD displays Creator District controls and authoritative career snapshot.
- [ ] Run actual UE 5.8 sign-in/runtime proof on Windows.

### Task 4: Creator District + avatar + movement + one vehicle
- [x] Third-person player movement/camera/jump/avatar loadout source.
- [x] Creator District graybox generator with Studio, Live Venue, Hub, Apartment, Store, Gym, roads, spawn, lighting.
- [x] Drivable proxy vehicle with enter/exit interaction and no Marketplace dependency.
- [x] Studio and rap-battle interaction portals placed by the generator.
- [ ] Run actual UE 5.8 collision/control/map generation proof.

### Task 5: Studio mission vertical loop
- [x] `MVP_FIRST_SESSION` accept + Starter Studio launch RPCs wired.
- [x] `tgg_world_v8_mark_session_launch_opened` wired before browser handoff.
- [x] Starter Studio portal opens Recording Studio with the real launch UUID.
- [x] Browser bridge creates a real `tgg_studio_projects` project/version and calls authoritative `tgg_world_v10_creator_session_saved`.
- [x] Bridge injected into staging theme and XML parse validated.
- [ ] Deploy bridge to live Blogger. Current v98 OAuth connection reports `google_oauth_invalid_grant`; legacy Chrome deploy worker is stale.
- [ ] Run real signed-in Studio save + `/p/tgg-world-e2e-verifier.html` proof. Synthetic evidence remains prohibited.

### Task 6: Rap battle slice
- [x] Tested deterministic three-round BattleCore.
- [x] Unreal rap battle subsystem.
- [x] Live Venue interaction portal with visible round scores/totals/winner presentation.
- [ ] Replace simulated timing/style/crowd inputs with polished skill UI after first runtime compile.

### Task 7: Online + voice seam
- [x] OnlineSubsystemEOS plugin and fail-soft online subsystem seam.
- [x] HTTPS-only LiveKit token-endpoint configuration seam; no LiveKit secret in client.
- [ ] Configure real EOS product/deployment IDs and prove a two-player Unreal session.
- [ ] Connect LiveKit runtime room/audio in Unreal and verify two users.

### Task 8: Packaging and vertical-slice QA
- [x] One-command Windows toolchain verifier.
- [x] One-command UE 5.8 editor compile → district generation → BuildCookRun package pipeline.
- [ ] Run UE 5.8 compile/cook/package on Windows workstation.
- [ ] Fix any Unreal compiler/runtime issues found by that run.
- [ ] Execute packaged login/movement/vehicle/studio/mission/battle/persistence/2-user QA.
- [ ] Add runtime Sentry/PostHog instrumentation and produce final release-readiness report.
