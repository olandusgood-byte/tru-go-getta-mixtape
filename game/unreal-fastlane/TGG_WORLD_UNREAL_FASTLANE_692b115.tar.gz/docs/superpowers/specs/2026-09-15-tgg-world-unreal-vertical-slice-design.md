# TRU GO GETTA WORLD — Unreal Vertical Slice Design

Date: 2026-09-15
Status: Approved fast-lane architecture

## Goal
Ship a playable Windows vertical slice that proves the TRU GO GETTA WORLD career loop in Unreal while reusing the existing v15.1 Blogger/Supabase production logic and verified backend instead of rebuilding the platform.

## Scope
The first Unreal slice contains one Creator District, one customizable player avatar, on-foot movement, one drivable vehicle, one enterable recording studio, the `MVP_FIRST_SESSION` mission, one rap battle, local inventory/economy presentation, Supabase-backed career persistence, and a two-player online/voice seam ready for EOS + LiveKit integration.

Out of scope for this slice: a full city, large NPC population, family simulation, multiple properties, large multiplayer shards, custom vehicle fleet, final art pass, and the complete GTA/2K/Sims-scale feature set.

## Reuse From Existing TGG WORLD v15.1
The Unreal port preserves these existing contracts:

- Career tiers: Underground 0, Local Buzz 250, Rising Artist 750, Regional Name 1500, Breakout 3000, National 6000, Headliner 12000, Mogul 25000 reputation.
- Rap battle player round score: timing 35%, style 35%, crowd 30%, each input clamped to 0..1.
- Mission `MVP_FIRST_SESSION`: first real studio session; reward display contract 100 XP, 25 Rep, 250 Credits.
- Mission completion remains server/evidence driven. The client never fabricates verified evidence, rewards, Vault handoffs, crew membership, or event access.
- Supabase is persistence/auth/backend. Unreal never embeds privileged Supabase credentials.
- Creator OS studio handoff remains a boundary: the game launches a creator session and receives a real saved-session signal/evidence path.

## Architecture
### Game Client
Unreal Engine 5.8, C++ for deterministic gameplay/domain logic and Blueprints for presentation/level iteration. The portable core has no Unreal dependency so rules can be tested quickly outside the editor.

### Portable Core
Three deterministic units:
- `CareerCore`: reputation to career tier mapping.
- `BattleCore`: battle state and deterministic scoring; the presentation layer supplies opponent score/randomness.
- `MissionCore`: mission state/progress transitions and evidence-pending state.

### Unreal Layer
The Unreal module wraps the portable core and later adds Character, GameMode, UI, vehicle, district, studio interaction, and online seams. Core rules remain independent of rendering/network code.

### Backend Boundary
Supabase remains authoritative for player career state and verified mission evidence/rewards. Live creator proof must originate from authenticated user flows; administrative SQL is never used to fake production evidence.

### Online Boundary
EOS provides sessions/lobbies/friends where appropriate. LiveKit provides voice/calls. The first slice requires a clean adapter boundary so either service can be tested independently.

## Data Flow
1. Player signs in.
2. Unreal loads player career/profile from the backend adapter.
3. Player accepts `MVP_FIRST_SESSION`.
4. Player travels to Starter Studio and starts a creator session.
5. Creator OS/Recording Studio saves a real project/version.
6. Backend records/verifies mission evidence and grants reward exactly once.
7. Unreal refreshes career state and updates UI.

## Failure Rules
- Missing authentication: fail closed and request sign-in.
- Missing backend connectivity: permit offline movement/battle sandbox only; do not grant online rewards.
- Duplicate completion: backend idempotency wins; client displays returned authoritative state.
- Voice/session failure: gameplay remains available; online/voice status is degraded visibly.

## Testing
- Portable unit tests cover career tier boundaries, score clamping, round completion, winner selection, mission progress clamping, and evidence-pending transition.
- A scaffold verifier validates the `.uproject` and required source/config paths without requiring Unreal to be installed.
- Unreal editor/package compilation must be run on a Windows workstation with Unreal 5.8 before any packaged-build claim.
- Production completion requires the real signed-in E2E verifier; synthetic DB rows do not count.

## Fast-Lane Success Criteria
A Windows build where a real player can spawn in Creator District, move, drive one vehicle, enter the recording studio, accept/advance `MVP_FIRST_SESSION`, complete a rap battle, reload persisted career state, and establish the online/voice adapter seam without privileged secrets in the client.
