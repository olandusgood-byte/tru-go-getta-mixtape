(function () {
  'use strict';

  if ((window.location.pathname || '') !== '/p/recording-studio.html') return;
  if (window.__TGG_RECORDING_WORLD_V10_BRIDGE__) return;

  const query = new URLSearchParams(window.location.search || '');
  if (query.get('tgg_world') !== '1') return;

  const launchId = (query.get('launch_id') || '').trim();
  if (!launchId) return;

  window.__TGG_RECORDING_WORLD_V10_BRIDGE__ = true;

  const PROJECT_URL = 'https://xsofowzvwetamhyuvlpj.supabase.co';
  const PUBLISHABLE_KEY = 'sb_publishable_mJQg4LjW-9KsW5B1zzJH8Q_e-kA-bbv';
  const MISSION_CODE = 'MVP_FIRST_SESSION';
  const projectStorageKey = 'tgg-world-v10-project:' + launchId;
  let busy = false;
  let privateClient = null;

  function status(message, bad) {
    const targets = [
      document.getElementById('engineStatus'),
      document.getElementById('cloudStatus950')
    ].filter(Boolean);
    targets.forEach(function (el) {
      el.textContent = message;
      if (bad) el.setAttribute('data-tgg-world-error', 'true');
      else el.removeAttribute('data-tgg-world-error');
    });
    console[bad ? 'error' : 'info']('[TGG WORLD v10]', message);
  }

  async function client() {
    const shared =
      window.tggSupabaseClient ||
      window.supabaseClient ||
      window.TGG_SUPABASE_CLIENT ||
      (window.TGG_V54 && (window.TGG_V54.client ||
        (typeof window.TGG_V54.getClient === 'function' ? window.TGG_V54.getClient() : null)));
    if (shared && shared.auth && typeof shared.rpc === 'function') return shared;
    if (privateClient) return privateClient;

    const mod = await import('https://esm.sh/@supabase/supabase-js@2.116.0');
    privateClient = mod.createClient(PROJECT_URL, PUBLISHABLE_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    return privateClient;
  }

  function projectSnapshot() {
    let local = null;
    try { local = JSON.parse(localStorage.getItem('tgg-nova-session') || 'null'); } catch (_) {}
    const title =
      (document.getElementById('projectName')?.textContent || local?.name || 'NOVA Recording').trim() ||
      'NOVA Recording';
    const bpmText = document.getElementById('projectMeta')?.textContent || '';
    const bpmMatch = bpmText.match(/Tempo\s+(\d+(?:\.\d+)?)/i);
    const bpm = bpmMatch ? Number(bpmMatch[1]) : 120;
    const musicalKey =
      document.getElementById('songKey')?.value ||
      document.getElementById('key')?.value ||
      null;

    return {
      title,
      bpm: Number.isFinite(bpm) ? bpm : 120,
      musicalKey,
      payload: {
        project_type: 'recording',
        engine: 'nova-world-v10',
        source: 'tgg-world',
        launch_id: launchId,
        mission_code: MISSION_CODE,
        nova_session: local || null,
        saved_at: new Date().toISOString()
      }
    };
  }

  async function ensureProject(sb, user, snapshot) {
    const cachedId = localStorage.getItem(projectStorageKey) || query.get('project_id') || '';
    if (cachedId) {
      const check = await sb.from('tgg_studio_projects')
        .select('id')
        .eq('id', cachedId)
        .eq('user_id', user.id)
        .maybeSingle();
      if (!check.error && check.data?.id) {
        const updated = await sb.from('tgg_studio_projects')
          .update({
            title: snapshot.title,
            bpm: snapshot.bpm,
            musical_key: snapshot.musicalKey,
            project_data: snapshot.payload,
            project_type: 'recording',
            updated_at: new Date().toISOString()
          })
          .eq('id', cachedId)
          .eq('user_id', user.id)
          .select('id')
          .single();
        if (updated.error) throw updated.error;
        return updated.data.id;
      }
    }

    const inserted = await sb.from('tgg_studio_projects')
      .insert({
        user_id: user.id,
        title: snapshot.title,
        bpm: snapshot.bpm,
        musical_key: snapshot.musicalKey,
        status: 'draft',
        project_type: 'recording',
        project_data: snapshot.payload
      })
      .select('id')
      .single();
    if (inserted.error) throw inserted.error;
    localStorage.setItem(projectStorageKey, inserted.data.id);
    return inserted.data.id;
  }

  async function createVersion(sb, user, projectId, snapshot) {
    const latest = await sb.from('tgg_studio_versions')
      .select('version_number')
      .eq('project_id', projectId)
      .eq('user_id', user.id)
      .order('version_number', { ascending: false })
      .limit(1);
    if (latest.error) throw latest.error;
    const next = (latest.data?.[0]?.version_number || 0) + 1;

    const version = await sb.from('tgg_studio_versions')
      .insert({
        project_id: projectId,
        user_id: user.id,
        version_number: next,
        label: 'World Save ' + next,
        snapshot: snapshot.payload
      })
      .select('id').single();
    if (version.error) throw version.error;
    return { id: version.data.id, versionNumber: next };
  }

  async function proveWorldSave() {
    if (busy) return;
    busy = true;
    try {
      status('Saving authoritative TGG WORLD studio version…', false);
      const sb = await client();
      const auth = await sb.auth.getUser();
      if (auth.error) throw auth.error;
      const user = auth.data?.user;
      if (!user) throw new Error('AUTH_REQUIRED');

      const snapshot = projectSnapshot();
      const projectId = await ensureProject(sb, user, snapshot);
      const version = await createVersion(sb, user, projectId, snapshot);

      const result = await sb.rpc('tgg_world_v10_creator_session_saved', {
        p_launch_id: launchId,
        p_project_id: projectId,
        p_session_id: version.id,
        p_artifact_id: null,
        p_tool: 'recording',
        p_payload: {
          source: 'nova-world-v10-bridge',
          mission_code: MISSION_CODE,
          version_number: version.versionNumber
        }
      });
      if (result.error) throw result.error;

      const detail = {
        launchId,
        projectId,
        sessionId: version.id,
        artifactId: null,
        tool: 'recording',
        missionCode: MISSION_CODE,
        result: result.data
      };
      window.dispatchEvent(new CustomEvent('tgg-creator-session-saved', { detail }));
      window.__TGG_WORLD_LAST_CREATOR_SAVE__ = detail;
      status('TGG WORLD proof saved · mission verification submitted.', false);
    } catch (error) {
      status('TGG WORLD save proof failed: ' + (error?.message || String(error)), true);
    } finally {
      busy = false;
    }
  }

  function bind() {
    const button = document.getElementById('saveBtn');
    if (!button || button.dataset.tggWorldV10Bound === '1') return false;
    button.dataset.tggWorldV10Bound = '1';
    button.addEventListener('click', function () {
      // NOVA's normal local save is synchronous. Defer the authoritative
      // mirror so its latest local snapshot is already present.
      window.setTimeout(proveWorldSave, 0);
    });
    status('TGG WORLD session bridge armed for this launch.', false);
    return true;
  }

  if (!bind()) {
    let tries = 0;
    const timer = window.setInterval(function () {
      tries += 1;
      if (bind() || tries >= 40) window.clearInterval(timer);
    }, 250);
  }
})();
