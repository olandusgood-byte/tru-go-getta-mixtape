"""Create the TRU GO GETTA WORLD fast-lane Creator District graybox.

Run inside Unreal Engine 5.8 with Python Editor Script Plugin enabled:
UnrealEditor-Cmd.exe TGGWorld.uproject -run=pythonscript -script="EditorScripts/create_creator_district.py"
"""
import unreal

LEVEL_PATH = "/Game/Maps/CreatorDistrict_P"
CUBE_PATH = "/Engine/BasicShapes/Cube.Cube"

level_subsystem = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)


def spawn_actor(actor_class, label, location, rotation=(0.0, 0.0, 0.0)):
    actor = actor_subsystem.spawn_actor_from_class(
        actor_class,
        unreal.Vector(*location),
        unreal.Rotator(*rotation),
        False,
    )
    if not actor:
        raise RuntimeError(f"Could not spawn {label}")
    actor.set_actor_label(label)
    return actor


def spawn_block(label, location, scale):
    actor = spawn_actor(unreal.StaticMeshActor, label, location)
    mesh = unreal.load_asset(CUBE_PATH)
    if not mesh:
        raise RuntimeError(f"Could not load {CUBE_PATH}")
    actor.static_mesh_component.set_static_mesh(mesh)
    actor.set_actor_scale3d(unreal.Vector(*scale))
    return actor


def build():
    unreal.log("TGG: creating Creator District graybox")
    if not level_subsystem.new_level(LEVEL_PATH, True):
        raise RuntimeError(f"Could not create level {LEVEL_PATH}")

    # Ground and cross-shaped road corridor.
    spawn_block("Creator District Ground", (0.0, 0.0, -50.0), (45.0, 45.0, 1.0))
    spawn_block("Main Boulevard", (0.0, 0.0, 5.0), (45.0, 6.0, 0.12))
    spawn_block("Studio Avenue", (0.0, 0.0, 8.0), (6.0, 45.0, 0.12))

    # First-slice landmarks. Sizes are graybox only; art replaces these later.
    landmarks = [
        ("Starter Studio", (-2400.0, -1700.0, 350.0), (8.0, 6.0, 4.0)),
        ("Live Venue", (2250.0, -1650.0, 450.0), (10.0, 7.0, 5.0)),
        ("Creator Hub", (2100.0, 1850.0, 500.0), (9.0, 8.0, 6.0)),
        ("Apartment", (-2100.0, 1850.0, 550.0), (7.0, 7.0, 7.0)),
        ("Creator Store", (0.0, -2450.0, 300.0), (6.0, 5.0, 3.5)),
        ("Gym", (0.0, 2450.0, 350.0), (7.0, 6.0, 4.0)),
    ]
    for label, location, scale in landmarks:
        spawn_block(label, location, scale)

    # Spawn/player and simple editor lighting.
    spawn_actor(unreal.PlayerStart, "TGG Player Start", (0.0, 0.0, 150.0))

    # Drivable proxy vehicle. It uses the native TGGVehiclePawn class and
    # engine cube geometry so the first slice needs no marketplace vehicle asset.
    vehicle_class = unreal.load_class(None, "/Script/TGGWorld.TGGVehiclePawn")
    if vehicle_class:
        spawn_actor(vehicle_class, "TGG Starter Ride", (650.0, 250.0, 90.0), (0.0, 0.0, 0.0))
    else:
        unreal.log_warning("TGGVehiclePawn class not loaded; compile the TGGWorld module before regenerating the map")

    # Interactive entrance for the MVP_FIRST_SESSION flow. Press E while aiming at
    # this portal to accept the mission, request/mark the launch, and open the
    # real Blogger Recording Studio with its authoritative launch UUID.
    portal_class = unreal.load_class(None, "/Script/TGGWorld.TGGStudioPortal")
    if portal_class:
        spawn_actor(portal_class, "TGG Starter Studio Portal", (-2400.0, -1050.0, 170.0), (0.0, 0.0, 0.0))
    else:
        unreal.log_warning("TGGStudioPortal class not loaded; compile the TGGWorld module before regenerating the map")

    battle_portal_class = unreal.load_class(None, "/Script/TGGWorld.TGGRapBattlePortal")
    if battle_portal_class:
        spawn_actor(battle_portal_class, "TGG Live Venue Rap Battle", (2250.0, -900.0, 160.0), (0.0, 0.0, 0.0))
    else:
        unreal.log_warning("TGGRapBattlePortal class not loaded; compile the TGGWorld module before regenerating the map")

    # Creator Store: four verified live catalog items. Purchases and equips are
    # server-authoritative; these actors only request the existing RPCs.
    store_item_class = unreal.load_class(None, "/Script/TGGWorld.TGGStoreItemPortal")
    if store_item_class:
        store_items = [
            ("Runner Pack", "runner-pack", 80, (-420.0, -1850.0, 120.0)),
            ("Red Chain", "red-chain", 90, (-140.0, -1850.0, 120.0)),
            ("TGG Black Hoodie", "starter-black-hoodie", 120, (140.0, -1850.0, 120.0)),
            ("Black High Tops", "v11_high_top_black", 300, (420.0, -1850.0, 120.0)),
        ]
        for display_name, item_key, price, location in store_items:
            item = spawn_actor(store_item_class, f"TGG Store · {display_name}", location)
            item.set_editor_property("item_key", item_key)
            item.set_editor_property("display_name", display_name)
            item.set_editor_property("price", price)
            item.set_editor_property("equip_after_purchase", True)
    else:
        unreal.log_warning("TGGStoreItemPortal class not loaded; compile the TGGWorld module before regenerating the map")

    # Gym portal recovers any active server workout, starts a gym workout when
    # none exists, and only finishes after the backend timer says it is ready.
    gym_portal_class = unreal.load_class(None, "/Script/TGGWorld.TGGGymPortal")
    if gym_portal_class:
        spawn_actor(gym_portal_class, "TGG Gym Workout Portal", (0.0, 1850.0, 150.0), (0.0, 0.0, 0.0))
    else:
        unreal.log_warning("TGGGymPortal class not loaded; compile the TGGWorld module before regenerating the map")


    # Apartment / property portal. First interaction loads the authoritative
    # apartment + phone bundle; the next interaction can purchase the Creator
    # Loft using virtual TGG credits through an idempotent server RPC.
    apartment_portal_class = unreal.load_class(None, "/Script/TGGWorld.TGGApartmentPortal")
    if apartment_portal_class:
        spawn_actor(apartment_portal_class, "TGG Apartment + Creator Loft Portal", (-2100.0, 1100.0, 170.0), (0.0, 0.0, 0.0))
    else:
        unreal.log_warning("TGGApartmentPortal class not loaded; compile the TGGWorld module before regenerating the map")


    # Creator Hub career board: loads server-ranked career contracts and opportunity
    # matches, then accepts only a ready contract through the idempotent backend RPC.
    creator_hub_portal_class = unreal.load_class(None, "/Script/TGGWorld.TGGCreatorHubPortal")
    if creator_hub_portal_class:
        spawn_actor(creator_hub_portal_class, "TGG Creator Hub Career Board", (2100.0, 1100.0, 170.0), (0.0, 0.0, 0.0))
    else:
        unreal.log_warning("TGGCreatorHubPortal class not loaded; compile the TGGWorld module before regenerating the map")
    spawn_actor(unreal.DirectionalLight, "TGG Sun", (0.0, 0.0, 1200.0), (-35.0, -35.0, 0.0))
    spawn_actor(unreal.SkyLight, "TGG Sky Light", (0.0, 0.0, 1000.0))
    spawn_actor(unreal.ExponentialHeightFog, "TGG Height Fog", (0.0, 0.0, 0.0))

    if not level_subsystem.save_current_level():
        raise RuntimeError("Creator District level save failed")
    unreal.log("TGG: Creator District graybox created and saved")


if __name__ == "__main__":
    build()
