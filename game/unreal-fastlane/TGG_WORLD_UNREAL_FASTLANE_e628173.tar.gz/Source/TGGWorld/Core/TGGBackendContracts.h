#pragma once

namespace tgg::rpc {
inline constexpr const char* BootstrapPlayer = "tgg_world_mvp_v1_bootstrap_player";
inline constexpr const char* UpdateCharacterProfile = "tgg_world_update_character_profile";
inline constexpr const char* WalletEnsure = "tgg_world_wallet_ensure";
inline constexpr const char* Purchase = "tgg_world_purchase";
inline constexpr const char* InventoryEquip = "tgg_world_inventory_equip";
inline constexpr const char* WorkoutStatus = "tgg_world_workout";
inline constexpr const char* WorkoutStart = "tgg_world_workout_start";
inline constexpr const char* WorkoutFinish = "tgg_world_workout_finish";
inline constexpr const char* PhoneBundle = "tgg_world_phone_bundle";
inline constexpr const char* PhoneSaveState = "tgg_world_phone_save_state";
inline constexpr const char* ApartmentPhoneBundle = "tgg_world_apartment_phone_bundle";
inline constexpr const char* BuyProperty = "tgg_world_buy_property";
inline constexpr const char* CareerIndustryBundle = "tgg_world_v12_career_industry_bundle";
inline constexpr const char* AcceptCareerContract = "tgg_world_v12_accept_career_contract";
inline constexpr const char* AcceptMission = "tgg_world_mvp_v1_accept_mission";
inline constexpr const char* RequestSessionLaunch = "tgg_world_v3_request_session_launch";
inline constexpr const char* MarkSessionOpened = "tgg_world_v8_mark_session_launch_opened";
inline constexpr const char* CreatorSessionSaved = "tgg_world_v10_creator_session_saved";
inline constexpr const char* RecordMissionEvidence = "tgg_world_v4_record_mission_evidence";
inline constexpr const char* VerifyAndCompleteMission = "tgg_world_v4_verify_and_complete_mission";
inline constexpr const char* QueueEventReplay = "tgg_world_v3_queue_event_replay";
}
