#include "TGGBattleCore.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <utility>

namespace tgg {
Battle::Battle(int rounds, std::string opponentName)
    : rounds_(std::max(1, rounds)), opponentName_(std::move(opponentName)) {}

double Battle::Clamp01(double value) noexcept {
    if (!std::isfinite(value)) return 0.0;
    return std::max(0.0, std::min(1.0, value));
}

double Battle::Round2(double value) noexcept {
    return std::round(value * 100.0) / 100.0;
}

BattleRoundResult Battle::PlayRound(double timing, double style, double crowd, double opponentScore) {
    if (finished_) {
        return BattleRoundResult{currentRound_, 0.0, 0.0, true, winner_};
    }

    const double player = Round2(Clamp01(timing) * 35.0 + Clamp01(style) * 35.0 + Clamp01(crowd) * 30.0);
    const double opponent = Round2(std::max(0.0, opponentScore));

    playerTotal_ += player;
    opponentTotal_ += opponent;

    if (currentRound_ >= rounds_) {
        finished_ = true;
        winner_ = playerTotal_ >= opponentTotal_ ? "player" : "opponent";
    }

    BattleRoundResult result{currentRound_, player, opponent, finished_, winner_};
    log_.push_back(result);
    if (!finished_) {
        ++currentRound_;
    }
    return result;
}
}
