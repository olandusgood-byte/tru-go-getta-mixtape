#pragma once

#include <string>
#include <vector>

namespace tgg {
struct BattleRoundResult {
    int round = 0;
    double playerScore = 0.0;
    double opponentScore = 0.0;
    bool finished = false;
    std::string winner;
};

class Battle {
public:
    Battle(int rounds, std::string opponentName);
    BattleRoundResult PlayRound(double timing, double style, double crowd, double opponentScore);

    int CurrentRound() const noexcept { return currentRound_; }
    double PlayerTotal() const noexcept { return playerTotal_; }
    double OpponentTotal() const noexcept { return opponentTotal_; }
    bool Finished() const noexcept { return finished_; }
    const std::string& Winner() const noexcept { return winner_; }
    const std::string& OpponentName() const noexcept { return opponentName_; }
    const std::vector<BattleRoundResult>& Log() const noexcept { return log_; }

private:
    static double Clamp01(double value) noexcept;
    static double Round2(double value) noexcept;

    int rounds_ = 3;
    int currentRound_ = 1;
    std::string opponentName_;
    double playerTotal_ = 0.0;
    double opponentTotal_ = 0.0;
    bool finished_ = false;
    std::string winner_;
    std::vector<BattleRoundResult> log_;
};
}
