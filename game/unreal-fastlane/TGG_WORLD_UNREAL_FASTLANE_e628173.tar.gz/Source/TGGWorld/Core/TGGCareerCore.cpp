#include "TGGCareerCore.h"

#include <array>
#include <utility>

namespace tgg {
std::string CareerTierFromReputation(std::int64_t reputation) {
    static constexpr std::array<std::pair<const char*, std::int64_t>, 8> kRules{{
        {"Underground", 0},
        {"Local Buzz", 250},
        {"Rising Artist", 750},
        {"Regional Name", 1500},
        {"Breakout", 3000},
        {"National", 6000},
        {"Headliner", 12000},
        {"Mogul", 25000},
    }};

    const char* tier = kRules.front().first;
    for (const auto& [name, threshold] : kRules) {
        if (reputation >= threshold) {
            tier = name;
        }
    }
    return tier;
}
}
