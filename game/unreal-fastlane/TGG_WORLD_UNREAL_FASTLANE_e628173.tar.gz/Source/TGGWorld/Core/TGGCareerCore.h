#pragma once

#include <cstdint>
#include <string>

namespace tgg {
std::string CareerTierFromReputation(std::int64_t reputation);
}
