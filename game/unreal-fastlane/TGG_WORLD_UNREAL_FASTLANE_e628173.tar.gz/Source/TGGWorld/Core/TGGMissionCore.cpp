#include "TGGMissionCore.h"

#include <algorithm>
#include <cmath>
#include <utility>

namespace tgg {
MissionState::MissionState(std::string code, std::string title)
    : code_(std::move(code)), title_(std::move(title)) {}

void MissionState::SetProgress(double progress) noexcept {
    if (!std::isfinite(progress)) progress = 0.0;
    progress_ = std::max(0.0, std::min(100.0, progress));
    if (progress_ >= 100.0 && status_ == MissionStatus::Accepted) {
        status_ = MissionStatus::EvidencePending;
    }
}

void MissionState::MarkVerified() noexcept {
    if (status_ == MissionStatus::EvidencePending) {
        status_ = MissionStatus::Verified;
    }
}

void MissionState::MarkCompleted() noexcept {
    if (status_ == MissionStatus::Verified) {
        status_ = MissionStatus::Completed;
    }
}
}
