#pragma once

#include <string>

namespace tgg {
enum class MissionStatus {
    Accepted,
    EvidencePending,
    Verified,
    Completed
};

class MissionState {
public:
    MissionState(std::string code, std::string title);
    void SetProgress(double progress) noexcept;
    void MarkVerified() noexcept;
    void MarkCompleted() noexcept;

    const std::string& Code() const noexcept { return code_; }
    const std::string& Title() const noexcept { return title_; }
    double Progress() const noexcept { return progress_; }
    MissionStatus Status() const noexcept { return status_; }

private:
    std::string code_;
    std::string title_;
    double progress_ = 0.0;
    MissionStatus status_ = MissionStatus::Accepted;
};
}
