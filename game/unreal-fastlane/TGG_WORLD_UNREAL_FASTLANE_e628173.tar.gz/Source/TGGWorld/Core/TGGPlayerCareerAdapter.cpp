#include "TGGPlayerCareerAdapter.h"
#include "TGGCareerCore.h"

#include <stdexcept>

namespace tgg {
CareerSnapshot PlayerCareerAdapter::Refresh() {
    if (!gateway_.IsAuthenticated()) {
        throw std::runtime_error("AUTH_REQUIRED");
    }
    const auto stats = gateway_.LoadPlayerStats();
    CareerSnapshot snapshot;
    snapshot.xp = stats.xp;
    snapshot.reputation = stats.reputation;
    snapshot.audience = stats.audience;
    snapshot.level = stats.level;
    snapshot.tier = CareerTierFromReputation(stats.reputation);
    return snapshot;
}
}
